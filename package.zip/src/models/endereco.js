import { Model, DataTypes } from 'sequelize';

class Endereco extends Model {
    static init(sequelize) {
        super.init({
            rua: {
                type: DataTypes.STRING,
                allowNull: false
            },
            cidade: {
                type: DataTypes.STRING,
                allowNull: false
            },
            estado: {
                type: DataTypes.STRING,
                allowNull: false
            }
        }, {
            sequelize,
            modelName: 'endereco',
            tableName: 'enderecos'
        });
    }
}

export { Endereco };