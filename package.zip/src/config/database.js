import Sequelize from "sequelize";
import { Cliente } from "../models/cliente.js";
import { Produto } from "../models/produto.js";
import { Compra } from "../models/compra.js";

const sequelize = new Sequelize('crud', 'root', '', {
    dialect: 'mysql',
    host: 'localhost',
    port: 3333
});

Cliente.init(sequelize);
Produto.init(sequelize);
Compra.init(sequelize);

Cliente.associate({ Compra, Produto });
Produto.associate({ Compra, Cliente });
Compra.associate({ Cliente, Produto });


export { sequelize };