import { enderecoSchema } from "../schemas/enderecoSchema.js";

export function validarEndereco(req, res, next) {
    try {
        enderecoSchema.parse(req.body);
        next();
    } catch (e) {
        return res.status(400).json({
            erro: e.errors.map(err => err.message).join(", ")
        });
    }
}
