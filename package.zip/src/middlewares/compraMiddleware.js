import { compraSchema } from "../schemas/compraSchema.js";

export function validarCompra(req, res, next) {
    try {
        compraSchema.parse(req.body);
        next();
    } catch (e) {
        return res.status(400).json({
            erro: e.errors.map(err => err.message).join(", ")
        });
    }
}
