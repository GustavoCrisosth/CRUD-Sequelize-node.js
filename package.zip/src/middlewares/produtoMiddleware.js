import { produtoSchema } from "../schemas/produtoSchema.js";

export function validarProduto(req, res, next) {
    try {
        produtoSchema.parse(req.body);
        next();
    } catch (e) {
        return res.status(400).json({
            erro: e.errors.map(err => err.message).join(", ")
        });
    }
}
