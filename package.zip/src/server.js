import express from 'express';
import routes from './routes.js';
import './config/database.js';
import { sequelize } from './config/database.js';

const app = express();

app.use(express.json());

app.use(routes);

(async () => {
    try {
        await sequelize.authenticate()
        await sequelize.sync({ alter: true });
        console.log("Banco sincronizado!");

        app.listen(3333, () => console.log("server is running"));
    } catch (err) {
        console.error("Erro ao sincronizar banco:", err);
    }
})();
